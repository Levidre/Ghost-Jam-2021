Some Among Us balloon.
It mimicks the appearance of the tablet used by an Among Us player during the meetings.

